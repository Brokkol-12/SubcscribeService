package handlers

import (
	"encoding/json"
	"errors"
	"net/http"
	"subscription-service/configs"
	"subscription-service/internal/services"

	"github.com/google/uuid"
)

type SubsReadDeps struct {
	Config  *configs.Config
	Service *services.SubsService
}

type UpdateReadReq struct {
	ServiceName string `json:"service_name"`
	Price       uint   `json:"price"`
	EndDate     string `json:"end_date"`
}

type SubsRead struct {
	Config  *configs.Config
	service *services.SubsService
}

func NewSubsHandlerRead(router *http.ServeMux, deps SubsReadDeps) {
	handler := &SubsRead{
		Config:  deps.Config,
		service: deps.Service,
	}
	router.HandleFunc("/subs/read", handler.GetByID())
}

func (h *SubsUpdate) GetByID() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		if r.Method != http.MethodGet {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}

		idParam := r.URL.Query().Get("id")
		id, err := uuid.Parse(idParam)
		if err != nil {
			http.Error(w, "invalid subscription id", http.StatusBadRequest)
			return
		}

		subs, err := h.service.GetByID(r.Context(), id)
		if err != nil {

			if errors.Is(err, services.ErrNotFound) {
				http.Error(w, "subscription not found", http.StatusNotFound)
				return
			}

			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(subs)
	}
}
