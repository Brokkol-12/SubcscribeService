package handlers

import (
	"encoding/json"
	"net/http"
	"subscription-service/configs"
	"subscription-service/internal/services"
	"time"

	"github.com/google/uuid"
)

type SubsTotalDeps struct {
	Config  *configs.Config
	Service *services.SubsService
}

type UpdateTotalReq struct {
	ServiceName string `json:"service_name"`
	Price       uint   `json:"price"`
	EndDate     string `json:"end_date"`
}

type SubsTotal struct {
	Config  *configs.Config
	service *services.SubsService
}

func NewSubsHandlerTotal(router *http.ServeMux, deps SubsTotalDeps) {
	handler := &SubsTotal{
		Config:  deps.Config,
		service: deps.Service,
	}
	router.HandleFunc("/subs/total", handler.CalculateTotal())
}

func (h *SubsRead) CalculateTotal() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		if r.Method != http.MethodGet {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}

		userIDParam := r.URL.Query().Get("user_id")
		serviceName := r.URL.Query().Get("service_name")
		startParam := r.URL.Query().Get("start")
		endParam := r.URL.Query().Get("end")

		userID, err := uuid.Parse(userIDParam)
		if err != nil {
			http.Error(w, "invalid user_id", http.StatusBadRequest)
			return
		}

		startDate, err := time.Parse("2006-01-02", startParam)
		if err != nil {
			http.Error(w, "invalid start date format (use YYYY-MM-DD)", http.StatusBadRequest)
			return
		}

		endDate, err := time.Parse("2006-01-02", endParam)
		if err != nil {
			http.Error(w, "invalid end date format (use YYYY-MM-DD)", http.StatusBadRequest)
			return
		}

		total, err := h.service.CalculateTotal(
			r.Context(),
			userID,
			serviceName,
			startDate,
			endDate,
		)

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		response := map[string]uint{
			"total": total,
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(response)
	}
}
