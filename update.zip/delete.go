package handlers

import (
	"errors"
	"net/http"
	"strings"
	"subscription-service/internal/services"

	"github.com/google/uuid"
)

type Handler struct {
	service *services.SubsService
}
func NewDeleteHandler(router *http.ServeMux, service *services.SubsService) {
	h := &Handler{service: service}
	router.HandleFunc("/subscriptions/", h.Delete)
}

func (h *Handler) Delete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodDelete {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	ctx := r.Context()

	idStr := strings.TrimPrefix(r.URL.Path, "/subscriptions/")
	if idStr == "" {
		http.Error(w, "Missing ID", http.StatusBadRequest)
		return
	}

	id, err := uuid.Parse(idStr)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	err = h.service.Delete(ctx, id)
	if err != nil {
		if errors.Is(err, services.ErrNotFound) {
			http.Error(w, "Subscription Not Found", http.StatusNotFound)
			return
		}
		http.Error(w, "Internal Error", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}
