package handlers

import (
	"encoding/json"
	"net/http"
	"subscription-service/configs"
	"subscription-service/internal/services"
	"time"

	"github.com/google/uuid"
)

type SubsCreateDeps struct {
	Config  *configs.Config
	Service *services.SubsService
}

type CreateSubsReq struct {
	ServiceName string `json:"service_name"`
	Price       uint   `json:"price"`
	UserId      string `json:"user_id"`
	StartDate   string `json:"start_date"`
	EndDate     string `json:"end_date"`
}

type SubsCreate struct {
	Config  *configs.Config
	service *services.SubsService
}

func NewSubsHandler(router *http.ServeMux, deps SubsCreateDeps) {
	handler := &SubsCreate{
		Config:  deps.Config,
		service: deps.Service,
	}
	router.HandleFunc("/subs/create", handler.Create())
}

func (h *SubsCreate) Create() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}

		var body CreateSubsReq
		err := json.NewDecoder(r.Body).Decode(&body)
		if err != nil {
			http.Error(w, "Invalid Json Body", http.StatusBadRequest)
			return
		}

		userId, err := uuid.Parse(body.UserId)
		if err != nil {
			http.Error(w, "Invalid user ID", http.StatusBadRequest)
			return
		}

		start_date, err := time.Parse("01-2006", body.StartDate)
		if err != nil {
			http.Error(w, "Invalid date format, use MM-YYYY", http.StatusBadRequest)
			return
		}

		var end_date *time.Time
		if body.EndDate != "" {
			parsedEnd, err := time.Parse("01-2006", body.EndDate)
			if err != nil {
				http.Error(w, "Invalid date format, use MM-YYYY", http.StatusBadRequest)
				return
			}
			end_date = &parsedEnd
		}

		ctx := r.Context()

		subs, err := h.service.Create(
			ctx,
			userId,
			body.ServiceName,
			body.Price,
			start_date,
			end_date,
		)

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		if err := json.NewEncoder(w).Encode(subs); err != nil {
			http.Error(w, "Failed to write response", http.StatusInternalServerError)
			return
		}
	}
}
