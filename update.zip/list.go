package handlers

import (
	"encoding/json"
	"net/http"
	"subscription-service/configs"
	"subscription-service/internal/services"

	"github.com/google/uuid"
)

type SubsListDeps struct {
	Config  *configs.Config
	Service *services.SubsService
}

type UpdateListReq struct {
	ServiceName string `json:"service_name"`
	Price       uint   `json:"price"`
	EndDate     string `json:"end_date"`
}

type SubsList struct {
	service *services.SubsService
}

func NewSubsHandlerList(router *http.ServeMux, service *service.SubsListDeps) {
	handler := &SubsList{
		service: Service,
	}
	router.HandleFunc("/subs/list", handler.List())
}

func (h *SubsRead) List() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		if r.Method != http.MethodGet {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}

		userIDParam := r.URL.Query().Get("user_id")
		userID, err := uuid.Parse(userIDParam)
		if err != nil {
			http.Error(w, "invalid user_id", http.StatusBadRequest)
			return
		}

		serviceName := r.URL.Query().Get("service_name")

		subs, err := h.service.List(
			r.Context(),
			userID,
			serviceName,
		)

		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(subs)
	}
}
