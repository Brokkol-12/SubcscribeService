package handlers

import (
	"encoding/json"
	"net/http"
	"subscription-service/configs"
	"subscription-service/internal/services"
	"time"

	"github.com/google/uuid"
)

type SubsUpdateDeps struct {
	Config  *configs.Config
	Service *services.SubsService
}

type UpdateSubsReq struct {
	ServiceName string `json:"service_name"`
	Price       uint   `json:"price"`
	EndDate     string `json:"end_date"`
}

type SubsUpdate struct {
	Config  *configs.Config
	service *services.SubsService
}

func NewSubsHandlerUpdate(router *http.ServeMux, deps SubsUpdateDeps) {
	handler := &SubsUpdate{
		Config:  deps.Config,
		service: deps.Service,
	}
	router.HandleFunc("/subs/update", handler.Update())
}

func (h *SubsUpdate) Update() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idParam := r.URL.Query().Get("id")
		id, err := uuid.Parse(idParam)
		if err != nil {
			http.Error(w, "Invalid subscription id", http.StatusBadRequest)
		}
		var req UpdateSubsReq
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}
		var endDate *time.Time
		if req.EndDate != "" {
			parsed, err := time.Parse(time.RFC3339, req.EndDate)
			if err != nil {
				http.Error(w, "Invalid end_date forman", http.StatusBadRequest)
				return
			}
			endDate = &parsed
		}
		subs, err := h.service.Update(
			r.Context(),
			id,
			req.ServiceName,
			req.Price,
			endDate,
		)
		if err != nil {
			if err.Error() == "Subscription not found" {
				http.Error(w, err.Error(), http.StatusNotFound)
				return
			}
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(subs)
	}
}
